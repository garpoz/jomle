# garpozir@gmail.com

from django.shortcuts import render, redirect, HttpResponse
from os import path
from web_api.settings import BASE_DIR
import json
from django.http import HttpResponse

# from .con import convert
import requests, os, random


def index(request):
    x_forwarded_for = request.META.get("HTTP_X_FORWARDED_FOR")
    if x_forwarded_for:
        ip = x_forwarded_for.split(",")[0]
    else:
        ip = request.META.get("REMOTE_ADDR")
    lst_ip = open(f"{BASE_DIR}/ip", "r").read().split()
    if ip not in lst_ip:
        # return redirect("https://google.com/search?q=شما دسترسی ندارید")
        pass
    if request.GET:
        try:
            response_data = {}
            req_data = {}
            rnd = random.randint(1, 90000000)
            ir = request.GET["ir"]
            req_data["ir"] = ir.split("$")
            code = request.GET["code"]
            req_data["code"] = code.split("$")
            mony = request.GET["mony"]
            temp_mony = mony.split("$")
            temp_mony[0] = "{:,}".format(int(temp_mony[0]))
            req_data["mony"] = temp_mony
            id_bot = request.GET["id"]
            req_data["id"] = id_bot.split("$")
            img = request.GET["img"]
            sep = img.split(".")[-1]
            image_addr = f"{BASE_DIR}/app/static/{rnd}.{sep}"
            req_data["img"] = image_addr
            json_object = json.dumps(req_data, indent=4)
            lst_jsn = open(f"{BASE_DIR}/selenium/data.json", "w")
            lst_jsn.write(json_object)
            lst_jsn.close()
            os.system(
                f"wget {img} -O {BASE_DIR}/app/static/{rnd}.{sep};find {BASE_DIR}/app/static -size 0 -delete"
            )
            if path.exists(f"{BASE_DIR}/app/static/{rnd}.{sep}"):
                os.system(f'cd {BASE_DIR}/selenium&&python3 se.py')
                response_data["status"] = "ok"
                response_data["img"] = f"http://116.202.98.218/static/{rnd}.{sep}"
            else:
                response_data["status"] = "error"
                response_data["img"] = f"null"
            return HttpResponse(
                json.dumps(response_data), content_type="application/json"
            )
        except:
            response_data["status"] = "error"
            response_data["img"] = f"null"
            return HttpResponse(
                json.dumps(response_data), content_type="application/json"
            )

    return render(request, "app/index.html")


# Create your views here.

#! /usr/bin/python3
# behrouz_ashraf
# garpozir@gmail.com
# -*- coding: utf-8 -*-

from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.common.exceptions import TimeoutException
import time, os, json
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from my_css import css_func


jsn = open("./data.json", "r")
json_file = json.load(jsn)
jsn.close()
img_address = json_file["img"]
ir = json_file["ir"]
code = json_file["code"]
mony = json_file["mony"]
bot = json_file["id"]

color_list='blackwhiteredgreenblueyellowpinkbrown'
font_list='actionakbarbamboarashariaarshiaasemanbaranvazirdavatboingocastorwcrassfawnfreakpatriotrocktag'

if ir[3] not in font_list:
    ir[3]='vazir'

if code[3] not in font_list:
    code[3]='vazir'

if mony[3] not in font_list:
    mony[3]='vazir'

if bot[3] not in font_list:
    bot[3]='vazir'

if ir[1] not in color_list:
    ir[1]='black'

if code[1] not in color_list:
    code[1]='black'

if mony[1] not in color_list:
    mony[1]='black'

if bot[1] not in color_list:
    bot[1]='black'


def index_file(
    img: str, text: str = "", code: int = 0, mony: str = "", bot: str = None
) -> None:
    html = f"""
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width">
        <title>web api</title>
        <meta name="keywords" content="HTML, CSS, JavaScript">
        <meta name="author" content="garpozir@gmail.com">
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <div id="main-div">
            <img id="img-id" src="{img}" alt="error load image">
            <div class="cl-div" id="text-id">{text}</div>
            <div class="cl-div" id="code-id">{code}</div>
            <div class="cl-div" id="mony-id">{mony}</div>
            <div class="cl-div" id="bot-id">{bot}</div>
        </div>
    </body>
</html>"""
    save_html = open("./index.html", "w")
    save_html.write(html)
    save_html.close()


index_file(img=img_address, text=ir[0], code=code[0], mony=mony[0], bot=bot[0])

css_func(text=ir, code=code, mony=mony, bot=bot)

chrome_options = Options()
agent = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.5359.98 Safari/537.36"
chrome_options.add_argument(f"user-agent={agent}")
chrome_options.add_argument("--headless")
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--disable-dev-shm-usage")
d = webdriver.Chrome("/usr/bin/chromedriver", chrome_options=chrome_options)
# d.set_window_size(1080, 1080)
d.get("file:///root/web_api/web_api/selenium/index.html")
d.find_element("xpath", "//img[@id='img-id']").screenshot(img_address)
d.quit()

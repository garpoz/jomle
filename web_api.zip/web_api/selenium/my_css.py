#! /usr/bin/python3
# behrouz_ashraf
# garpozir@gmail.com
# -*- coding: utf-8 -*-

def css_func(text:list,code:list,mony:list,bot:list)->None:
    css=f"""
#main-div {
    position: relative;
    text-align: justify;
}

#text-id {
    color: {text[1]};
    font-family: "{text[3]}";
    font-size: {text[2]}px;
    top: {text[-1].split('*')[0]}px;
    left: {text[-1].split('*')[-1]}px;
}

#code-id {
    color: {code[1]};
    font-family: "{code[3]}";
    font-size: {code[2]}px;
    top: {code[-1].split('*')[0]}px;
    left: {code[-1].split('*')[-1]}px;
}

#mony-id {
    color: {mony[1]};
    font-family: "{mony[3]}";
    font-size: {mony[2]}px;
    top: {mony[-1].split('*')[0]}px;
    left: {mony[-1].split('*')[-1]}px;
}

#bot-id {
    color: {bot[1]};
    font-family: "{bot[3]}";
    font-size: {bot[2]}px;
    top: {bot[-1].split('*')[0]}px;
    left: {bot[-1].split('*')[-1]}px;
}

.cl-div {
    position: absolute;
}

#img-id {
    display: block;
    border: 2px solid black;
}

@font-face {
    font-family: "vazir";
    src: url("./fonts/Vazir-Black.ttf")
}



@font-face {
    font-family: "action";
    src: url("./fonts/actionj.ttf")
}
@font-face {
    font-family: "akbar";
    src: url("./fonts/akbar.ttf")
}
@font-face {
    font-family: "bambo";
    src: url("./fonts/Babe Bamboo.ttf")
}
@font-face {
    font-family: "arash";
    src: url("./fonts/aberatn.ttf")
}
@font-face {
    font-family: "aria";
    src: url("./fonts/NINJAS.TTF")
}
@font-face {
    font-family: "arshia";
    src: url("./fonts/B Kamran_p30downlad.com.ttf")
}
@font-face {
    font-family: "aseman";
    src: url("./fonts/nanosecw.ttf")
}
@font-face {
    font-family: "baran";
    src: url("./fonts/BALL___.TTF")
}
@font-face {
    font-family: "davat";
    src: url("./fonts/davyrib.ttf")
}
@font-face {
    font-family: "boingo";
    src: url("./fonts/boston.ttf")
}
@font-face {
    font-family: "castorw";
    src: url("./fonts/Catwalk.ttf")
}
@font-face {
    font-family: "crass";
    src: url("./fonts/caliph.ttf")
}
@font-face {
    font-family: "fawn";
    src: url("./fonts/fawn.ttf")
}
@font-face {
    font-family: "freak";
    src: url("./fonts/freak.ttf")
}
@font-face {
    font-family: "patriot";
    src: url("./fonts/planetbe.ttf")
}
@font-face {
    font-family: "rock";
    src: url("./fonts/RockFont.ttf")
}
@font-face {
    font-family: "tag";
    src: url("./fonts/tag.ttf")
}
"""

    save_css = open("./style.css", "w")
    save_css.write(css)
    save_css.close()


#! /usr/bin/python3
# behrouz_ashraf
# garpozir@gmail.com
# -*- coding: utf-8 -*-

import time
from django.shortcuts import render
from django.shortcuts import render, HttpResponse,redirect
import requests
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.common.exceptions import TimeoutException
import time, os, json
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

def index(request):
    return render(request,'index.html')

def search(request):
    if request.GET:
        chrome_options = Options()
        agent = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.5359.98 Safari/537.36"
        chrome_options.add_argument(f"user-agent={agent}")
        chrome_options.add_argument("--headless")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        d = webdriver.Chrome("/usr/bin/chromedriver", chrome_options=chrome_options)

        u_name = request.GET["query"]
        size=5
        r=requests.get(f"https://rest.uniprot.org/uniprotkb/search?query={u_name}&format=tsv&size={size}")
        st=list(r.text.split("\n"))
        lst=[]
        for i in st[1:]:
            lst.append(i.split("\t"))

        lst=lst[:-1]
        #func=[]
        
        
        #return 0
        for i in range(size):
            
            d.get(f"https://www.uniprot.org/uniprotkb/{lst[i][0]}/entry")

            
            d.implicitly_wait(2)
            time.sleep(2)
            lst[i][2]=d.find_element("xpath", "/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/main[1]/div[1]/div[2]/section[1]/div[1]/div[2]/div[1]").text[:-13]
            #print(lst[i][0])
        return render(request,'search.html',{'headers':lst})
    return render(request,'search.html')

